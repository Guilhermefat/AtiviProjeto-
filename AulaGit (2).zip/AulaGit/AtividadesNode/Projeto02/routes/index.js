const express = require ('express');

const router = express.Router();

router.get('/',(req,res) => {
    let obj = {
        'nome': req.query.nome
    };
    res.render('home', obj);

});




module.exports = router;









/*
router.get('/',(req,res) => {
    let obj = {
        'nome': req.query.nome,
        'idade': req.query.idade,
         mostrar: true,
         disciplinas:[
            {nome:'materia_1', qt: '20 aulas.'},
            {nome:'materia_2', qt: '18 aulas.'},
            {nome:'materia_3', qt: '30 aulas.'},
            {nome:'materia_4', qt: '48 aulas.'}
        ],
        frutas: ['Banana.','Maça.','Melancia.'],
        teste: '<strong> Testando Negrito! </strong>'
    };
    res.render('home', obj);
});

*/





/*
router.get('/',(req,res) => {
    let obj = {
        'nome': req.query.nome,
        'idade': req.query.idade,
    };
    res.render('home', obj);
}); 

/*

/*router.get('/',(req,res) => {
    let obj = {
      'nome':'Guilherme Souza',
      'idade': 19,
    };
    res.render('home', obj);
}); /*

  /*  res.render('home' , {
        'nome':'Guilherme Henrique de Souza ',
        'idade': 19 
    });  //para renderizar
}); */

module.exports = router;

