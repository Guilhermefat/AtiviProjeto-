//Rotas (quando o servidor for acessado, pra onde ele vai?)
const express = require('express');

const router = express.Router();


router.get('/posts/:slug',(req, res) => {   //numero aleatorio 
    let slug = req.params.slug;
    res.send('SLUG do post: ' + slug);
});

/*router.get('/posts/id',(req, res) => {   //numero aleatorio 
    let id = req.params.id;
    res.send('ID do post: ' + id);
});*/


router.get('/rota1',(req,res) => { //Primeiro rota // função anônima // dois parametros
    res.send("Página sobre Rota 1...");
});

 router.get('/rota2',(req,res) => { //Primeiro rota // função anônima // dois parametros
    res.json(req.query);
 });


module.exports = router;

