//fazendo a importação do express 
const express = require('express');
const router = require('./routes/index');
const mustache = require('mustache-express');

//configurações básicas do aplicativos 
const app = express();
app.use('/',router);  //Foi passado 1 rota pois criamos apenas 1

app.use(express.json());

app.engine('mst',mustache(__dirname + '/views/partials','.mst'));       //config o motor, extensão utilizada
app.set('view engine', 'mst');   //setar motor visual

// Pega o diretorio absoluto do projeto e aumenta para pasta views concatenando
app.set('views', __dirname + '/views');

module.exports = app; //exportamos o app, pois vamos importa-lo no servidor 