//Carregar o modulo http
const http = require ('http');

//Criar um servidor HTTP no qual envia uma msg
var server = http.createServer(function (resquest, response) {

    //Define o cabeçalho (header) com o tipo de resposta
    response.writeHead(200, {"contante-type" : "text/plain"});

    // mensagem de retorno 
    response.end("Ola Mundo Node! \n");
});
//porta que o servidor vai escutar
server.listen(3000);

//Mensagem ao iniciar o Servidor
console.log("Servidor iniciado em http://localhost:3000/");