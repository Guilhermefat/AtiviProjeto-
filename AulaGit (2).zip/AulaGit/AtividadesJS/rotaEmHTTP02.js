//Carrega modulo HTTP e URL
var fs = require ('fs');
var http = require ('http');
var url = require ('url');

//Função para ler num arquivo e escrevê-lo na response.

function readFile(response,file){
    //Faz a leitura do arquivo de forma assincrona 
    fs.readFile(file, function(err, data){
        // quando ler, escreve na response o conteúdo do arquivo JSON.
        response.and(data);
    });
}
//Função de callback para o servidor HTTP
var callback = function (request, response){
    //Define o cabeçalho (Header) com o tipo de resposta 
    response.whiteHead(200, {"content-type": "application/json: charset=utf-8"})
    //Fazo parse da URL separando o Caminho (rota)

var parts = url.parse(request.url);
var path = parts.path;
}

// verifica a rota 
if (parts.pash == "/rota1/cadastro"){
    //Retorna o Json do cadastro.Json
    readFile(Response, "Cadastro.jason");
} else if (parts.path == "/rota1/catalogo"){
     //Retorna o Json do catalogo.Json
    readFile(response, "catalogo.jason");
}else if (parts.path == "/rota1/dados"){
     //Retorna o Json do dados.Json
    readFile(response, "dados.jason");
}else {
    Response.end("Rota Não Mapeado: " + parts.path);
};


var server = http.createServer(callback);

server.listen(3000);

console.log("Servidor iniciado em http://localhost:3000/");