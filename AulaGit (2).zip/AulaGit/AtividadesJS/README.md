# AtividadesJS
Primeiro Projeto de GitHub Para Realizar os 30% na nota!
