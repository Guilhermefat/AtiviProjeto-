//Carregar o modulo http
var http = require ('http');
var url = require ('url');

//Criar um servidor HTTP no qual envia uma msg
var callback = function (resquest, response) {

    //Define o cabeçalho (header) com o tipo de resposta
    response.writeHead(200, {"contante-type" : "text/plain; charset=utf-8"});

    //faz o parse da URL separando o caminnho (rota)
    var parse = url.parse(resquest.url);

    //Verifica a rota 
    if (parts.path == "/"){
    response.end("Site Principal");
}else if (parts.path == "/rota1"){
    response.end("Site da Rota 1");
}else {
    response.end("Rota Invalida: " +  parts.path)
}

};

// Criar um Servidor HTTP que responde para todas as requisições
var server = http.createServer(callback);

//porta que o servidor vai escutar
server.listen(3000);

//Mensagem ao iniciar o Servidor
console.log("Servidor iniciado em http://localhost:3000/");